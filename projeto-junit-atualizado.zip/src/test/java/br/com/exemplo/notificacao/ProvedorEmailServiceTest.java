package br.com.exemplo.notificacao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para ProvedorEmailService")
class ProvedorEmailServiceTest {

    private ProvedorEmailService service;

    @BeforeEach
    void setUp() {
        service = new ProvedorEmailService();
    }

    @ParameterizedTest
    @ValueSource(strings = {"teste@exemplo.com", "user.name@domain.br"})
    @DisplayName("Deve validar emails corretos")
    void deveValidarEmailsValidos(String email) {
        assertTrue(service.validarEmail(email));
    }

    @ParameterizedTest
    @ValueSource(strings = {"invalido", "@domain.com", "user@"})
    @DisplayName("Deve rejeitar emails invalidos")
    void deveRejeitarEmailsInvalidos(String email) {
        assertFalse(service.validarEmail(email));
    }

    @Test
    @DisplayName("Deve formatar mensagem em HTML utilizando Text Blocks")
    void deveFormatarHTML() {
        String html = service.formatarMensagemHTML("Bem-vindo", "Olá fulano");
        assertTrue(html.contains("<h2>Bem-vindo</h2>"));
        assertTrue(html.contains("<p>Olá fulano</p>"));
    }
}