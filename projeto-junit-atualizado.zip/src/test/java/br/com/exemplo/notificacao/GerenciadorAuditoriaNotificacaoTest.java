package br.com.exemplo.notificacao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para GerenciadorAuditoriaNotificacao")
class GerenciadorAuditoriaNotificacaoTest {

    private GerenciadorAuditoriaNotificacao auditoria;

    @BeforeEach
    void setUp() {
        auditoria = new GerenciadorAuditoriaNotificacao();
    }

    @Test
    @DisplayName("Deve registrar e recuperar historico de auditoria")
    void deveRegistrarHistorico() {
        Notificacao n = new Notificacao("1", "user@test.com", "Msg", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.ENVIADO, LocalDateTime.now());
        auditoria.registrar(n);

        assertEquals(1, auditoria.getHistorico().size());
        assertEquals(1, auditoria.contarPorStatus(StatusNotificacao.ENVIADO));
    }
}