package br.com.exemplo.notificacao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para PrioridadeNotificacao Enum")
class PrioridadeNotificacaoTest {

    @Test
    @DisplayName("Deve identificar corretamente prioridades urgentes")
    void deveIdentificarUrgentes() {
        assertAll(
            () -> assertFalse(PrioridadeNotificacao.BAIXA.isUrgente()),
            () -> assertFalse(PrioridadeNotificacao.MEDIA.isUrgente()),
            () -> assertTrue(PrioridadeNotificacao.ALTA.isUrgente()),
            () -> assertTrue(PrioridadeNotificacao.CRITICA.isUrgente())
        );
    }

    @Test
    @DisplayName("Deve respeitar a hierarquia numérica de níveis")
    void deveRespeitarHierarquia() {
        assertTrue(PrioridadeNotificacao.CRITICA.getNivel() > PrioridadeNotificacao.ALTA.getNivel());
        assertTrue(PrioridadeNotificacao.ALTA.getNivel() > PrioridadeNotificacao.MEDIA.getNivel());
    }
}