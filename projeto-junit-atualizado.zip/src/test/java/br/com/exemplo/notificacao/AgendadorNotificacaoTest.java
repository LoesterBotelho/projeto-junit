package br.com.exemplo.notificacao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para AgendadorNotificacao")
class AgendadorNotificacaoTest {

    private AgendadorNotificacao agendador;

    @BeforeEach
    void setUp() {
        agendador = new AgendadorNotificacao();
    }

    @Test
    @DisplayName("Deve agendar notificacao pendente com sucesso")
    void deveAgendarComSucesso() {
        Notificacao n = new Notificacao("1", "user@test.com", "Msg", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, LocalDateTime.now());
        agendador.agendar(n);

        assertEquals(1, agendador.quantidadePendente());
    }

    @Test
    @DisplayName("Nao deve agendar notificacao que nao esta PENDENTE")
    void deveLancarExcecaoParaNotificacaoNaoPendente() {
        Notificacao n = new Notificacao("1", "user@test.com", "Msg", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.ENVIADO, LocalDateTime.now());

        assertThrows(IllegalArgumentException.class, () -> agendador.agendar(n));
    }

    @Test
    @DisplayName("Deve cancelar notificacao agendada por ID")
    void deveCancelarNotificacao() {
        Notificacao n = new Notificacao("10", "user@test.com", "Msg", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, LocalDateTime.now());
        agendador.agendar(n);

        boolean cancelado = agendador.cancelar("10");

        assertTrue(cancelado);
        assertEquals(0, agendador.quantidadePendente());
    }
}