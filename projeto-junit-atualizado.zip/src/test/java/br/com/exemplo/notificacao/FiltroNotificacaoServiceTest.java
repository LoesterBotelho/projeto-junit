package br.com.exemplo.notificacao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para FiltroNotificacaoService")
class FiltroNotificacaoServiceTest {

    private FiltroNotificacaoService filtro;
    private List<Notificacao> lista;

    @BeforeEach
    void setUp() {
        filtro = new FiltroNotificacaoService();
        lista = List.of(
            new Notificacao("1", "a@test.com", "A", CanalNotificacao.EMAIL, PrioridadeNotificacao.BAIXA, StatusNotificacao.PENDENTE, LocalDateTime.now()),
            new Notificacao("2", "+5511999999999", "B", CanalNotificacao.SMS, PrioridadeNotificacao.CRITICA, StatusNotificacao.ENVIADO, LocalDateTime.now())
        );
    }

    @Test
    @DisplayName("Deve filtrar mensagens por canal")
    void deveFiltrarPorCanal() {
        List<Notificacao> emails = filtro.filtrarPorCanal(lista, CanalNotificacao.EMAIL);
        assertEquals(1, emails.size());
        assertEquals("1", emails.get(0).id());
    }

    @Test
    @DisplayName("Deve filtrar mensagens urgentes")
    void deveFiltrarUrgentes() {
        List<Notificacao> urgentes = filtro.filtrarUrgentes(lista);
        assertEquals(1, urgentes.size());
        assertEquals(PrioridadeNotificacao.CRITICA, urgentes.get(0).prioridade());
    }
}