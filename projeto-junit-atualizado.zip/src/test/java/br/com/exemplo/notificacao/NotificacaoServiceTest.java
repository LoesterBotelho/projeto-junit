package br.com.exemplo.notificacao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class NotificacaoServiceTest {

    private AgendadorNotificacao agendador;
    private GerenciadorAuditoriaNotificacao auditoria;
    private NotificacaoService service;

    @BeforeEach
    void setUp() {
        agendador = new AgendadorNotificacao();
        auditoria = new GerenciadorAuditoriaNotificacao();
        service = new NotificacaoService(agendador, auditoria);
    }

    @Test
    void deveProcessarNotificacaoComSucesso() {

        Notificacao notificacao = new Notificacao(
            "1", 
            "Usuario Teste", 
            "Mensagem válida dentro do limite.", 
            CanalNotificacao.EMAIL, 
            PrioridadeNotificacao.ALTA, 
            StatusNotificacao.PENDENTE, 
            LocalDateTime.now()
        );

        Notificacao resultado = service.processarNotificacao(notificacao);


        assertEquals(StatusNotificacao.ENVIADO, resultado.status());
        assertEquals(1, agendador.quantidadePendente());
        assertEquals(1, auditoria.getHistorico().size());
    }

    @Test
    void deveFiltrarNotificacoesPorPrioridadeCorretamente() {
        Notificacao n1 = new Notificacao("1", "User1", "Teste 1", CanalNotificacao.EMAIL, PrioridadeNotificacao.ALTA, StatusNotificacao.PENDENTE, LocalDateTime.now());
        Notificacao n2 = new Notificacao("2", "User2", "Teste 2", CanalNotificacao.SMS, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, LocalDateTime.now());

        List<Notificacao> lista = List.of(n1, n2);

        List<Notificacao> filtradas = FiltroNotificacaoService.filtrarPorPrioridade(lista, PrioridadeNotificacao.ALTA);

        assertEquals(1, filtradas.size());
        assertEquals("1", filtradas.get(0).id());
        assertEquals(PrioridadeNotificacao.ALTA, filtradas.get(0).prioridade());
    }

    @Test
    void deveLancarExcecaoParaNotificacaoNula() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.processarNotificacao(null);
        });
    }
}