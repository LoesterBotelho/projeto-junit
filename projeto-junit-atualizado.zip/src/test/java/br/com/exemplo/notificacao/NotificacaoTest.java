package br.com.exemplo.notificacao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para a Record Notificacao")
class NotificacaoTest {

    @Test
    @DisplayName("Deve criar notificação válida com sucesso")
    void deveCriarNotificacaoValida() {
        LocalDateTime agora = LocalDateTime.now();
        Notificacao n = new Notificacao("1", "user@test.com", "Olá", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, agora);

        assertAll(
            () -> assertEquals("1", n.id()),
            () -> assertEquals("user@test.com", n.destinatario()),
            () -> assertEquals(StatusNotificacao.PENDENTE, n.status()),
            () -> assertEquals(agora, n.dataCriacao())
        );
    }

    @Test
    @DisplayName("Deve lancar excecao para parametros nulos ou em branco")
    void deveLancarExcecaoParaEntradasInvalidas() {
        assertThrows(NullPointerException.class, () -> 
            new Notificacao(null, "user@test.com", "Olá", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, LocalDateTime.now())
        );

        assertThrows(IllegalArgumentException.class, () -> 
            new Notificacao("1", "   ", "Olá", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, LocalDateTime.now())
        );
    }

    @Test
    @DisplayName("Deve alterar o status criando nova instancia imutavel")
    void deveAlterarStatusComSucesso() {
        Notificacao original = new Notificacao("1", "user@test.com", "Olá", CanalNotificacao.EMAIL, PrioridadeNotificacao.MEDIA, StatusNotificacao.PENDENTE, LocalDateTime.now());
        Notificacao atualizada = original.comStatus(StatusNotificacao.ENVIADO);

        assertEquals(StatusNotificacao.PENDENTE, original.status());
        assertEquals(StatusNotificacao.ENVIADO, atualizada.status());
    }
}