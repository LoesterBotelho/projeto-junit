package br.com.exemplo.notificacao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para ProvedorSmsService")
class ProvedorSmsServiceTest {

    private ProvedorSmsService service;

    @BeforeEach
    void setUp() {
        service = new ProvedorSmsService();
    }

    @Test
    @DisplayName("Deve validar numero de telefone no padrao internacional")
    void deveValidarTelefone() {
        assertTrue(service.validarTelefone("+5511988887777"));
        assertFalse(service.validarTelefone("11988887777"));
    }

    @Test
    @DisplayName("Deve truncar mensagem quando exceder o limite do SMS")
    void deveTruncarMensagemExcedente() {
        String textoLongo = "A".repeat(200);
        String resultado = service.truncarParaSms(textoLongo);

        assertEquals(160, resultado.length());
    }
}