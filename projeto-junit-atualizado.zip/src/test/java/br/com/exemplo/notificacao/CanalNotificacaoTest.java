package br.com.exemplo.notificacao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para CanalNotificacao Enum")
class CanalNotificacaoTest {

    @ParameterizedTest
    @EnumSource(CanalNotificacao.class)
    @DisplayName("Deve possuir limites de caracteres positivos em todos os canais")
    void devePossuirLimitesValidos(CanalNotificacao canal) {
        assertTrue(canal.getLimiteCaracteres() > 0);
    }

    @Test
    @DisplayName("Deve validar corretamente o tamanho de texto suportado para SMS")
    void deveValidarTamanhoSMS() {
        String textoCurto = "Sms curto";
        String textoLongo = "A".repeat(161);

        assertTrue(CanalNotificacao.SMS.suportaTamanho(textoCurto));
        assertFalse(CanalNotificacao.SMS.suportaTamanho(textoLongo));
    }
}