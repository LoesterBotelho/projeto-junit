package br.com.exemplo.notificacao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes para StatusNotificacao Enum")
class StatusNotificacaoTest {

    @Test
    @DisplayName("Deve verificar se o status representa um estado finalizado")
    void deveVerificarStatusFinalizado() {
        assertAll(
            () -> assertFalse(StatusNotificacao.PENDENTE.isFinalizado()),
            () -> assertFalse(StatusNotificacao.EM_PROCESSAMENTO.isFinalizado()),
            () -> assertTrue(StatusNotificacao.ENVIADO.isFinalizado()),
            () -> assertTrue(StatusNotificacao.FALHA.isFinalizado()),
            () -> assertTrue(StatusNotificacao.CANCELADO.isFinalizado())
        );
    }
}